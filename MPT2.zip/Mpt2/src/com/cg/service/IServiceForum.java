package com.cg.service;

import com.cg.bean.Query_Master;

public interface IServiceForum {
	public Query_Master getQueryId(int id);
}
