package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Query_Master;
import com.cg.dao.IDAoForum;

@Service
public class ForumServiceImpl implements IServiceForum {

	@Autowired
	IDAoForum idf;
	
	public IDAoForum getIdf() {
		return idf;
	}
	public void setIdf(IDAoForum idf) {
		this.idf = idf;
	}
	@Override
	public Query_Master getQueryId(int id) {
		// TODO Auto-generated method stub
		return idf.getQueryId(id);
	}
	

}
