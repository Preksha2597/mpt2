package com.cg.dao;

import com.cg.bean.Query_Master;

public interface IDAoForum {
	public Query_Master getQueryId(int id);
}
