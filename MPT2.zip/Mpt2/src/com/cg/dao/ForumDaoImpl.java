package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.bean.Query_Master;


@Repository

public class ForumDaoImpl implements IDAoForum {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Query_Master getQueryId(int id) {
		// TODO Auto-generated method stub
		Query_Master f=null;
		f=entityManager.find(Query_Master.class, id);
		return f;
	}

	
	
	
	
}