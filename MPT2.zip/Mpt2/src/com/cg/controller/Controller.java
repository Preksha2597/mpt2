package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Query_Master;
import com.cg.service.IServiceForum;

@org.springframework.stereotype.Controller
public class Controller {
	
	@Autowired
	private IServiceForum isf;
	
	public IServiceForum getIsf() {
		return isf;
	}
	public void setIsf(IServiceForum isf) {
		this.isf = isf;
	}
	@RequestMapping("/showQuery")
	public String showLogin() {
		// Create an attribute of type Question
		return "RegistrationQuery";
	}
	@RequestMapping("/takeToSecondPage")
	public ModelAndView  secondPage(@RequestParam("query") int query) {
		ModelAndView mv = null;
		
		Query_Master m=isf.getQueryId(query);
		if(m==null) {
			mv= new ModelAndView("error");
			mv.addObject("queryID",m);
		}
		else {
			mv = new ModelAndView("SecondPage");
			mv.addObject("queryID",m);
			
		}
		
		return mv;
	}
	
	@RequestMapping("/success")
	public ModelAndView  showSuccessPage(@RequestParam("query") int query) {
		ModelAndView mv = null;
		Query_Master m=isf.getQueryId(query);
		mv = new ModelAndView("success");
		mv.addObject("queryID",m);
		return mv;
	}
	
}
